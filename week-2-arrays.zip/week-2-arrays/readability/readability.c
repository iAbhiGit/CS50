#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>


float avg_letters(string s);
float avg_sent(string s);


int main(void)
{
    string s = get_string("Text: ");
    float letters = avg_letters(s);
    float sentences = avg_sent(s);
    float grade = 0.0588 * letters - 0.296 * sentences - 15.8;

    if (grade > 16)
    {
        printf("Grade 16+\n");
    }
    else if (grade < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %d\n", (int) round(grade));
    }

}



float avg_letters(string s)
{
    float letters = 0;
    int words = 1;

    for (int i = 0; i < strlen(s); i++)

        if (isalpha(s[i]))
        {
            letters = letters + 1;
        }

    for (int i = 0; i < strlen(s); i++)

        if (isspace(s[i]))
        {
            words = words + 1;
        }

    letters = 100.00 * letters / words;

    return letters;

}

float avg_sent(string s)
{
    float sentences = 0;
    int words = 1;

    for (int i = 0; i < strlen(s); i++)
    {
        if (isspace(s[i]))
        {
            words = words + 1;
        }
    }

    for (int i = 0; i <= strlen(s); i++)
    {
        if (s[i] == '.' || s[i] == '?' || s[i] == '!')
        {
            sentences = sentences + 1;
        }
    }

    sentences = 100.00 * sentences / words;

    return sentences;
}
