#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    // Ensure proper usage
    if (argc != 2)
    {
        printf("Incorrect Input\n");
        return 1;
    }

    // Remember filename
    char *recover = argv[1];

    // Open recovery file
    FILE *file  = fopen(recover, "r");
    if (file == NULL)
    {
        printf("Could not open %s.\n", recover);
        return 2;
    }

    //create a buffer

    unsigned char buffer[512];
    char image[8];
    int count = 0;
    FILE *img = NULL;

    // Read infile
    while (fread(buffer, 1, 512, file) == 512)
    {

        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {

            if (count == 0) // if the file is the first jpeg file

            {
                // Start of the first jpeg file

                sprintf((char *)image, "%03i.jpg", count);
                img = fopen(image, "w");
                fwrite(buffer, 512, 1, img);
                count ++;

            }
            else
            {
                // closing the previous file
                fclose(img);
                sprintf((char *)image, "%03i.jpg", count);
                img = fopen(image, "w");
                fwrite(buffer, 512, 1, img);
                count++;
            }

        }
        else if (count > 0) // Since JPEGs are stored back to back, if its not a first file it certainly a jpeg file
        {
            fwrite(buffer, 512, 1, img);

        }

    }
    // closing the file
    fclose(img);
    fclose(file);

    return 0;

}