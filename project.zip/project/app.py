import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp


# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if not request.form.get("name"):
            return redirect("/")
        name = request.form.get("name")
        return render_template("questions.html", name=name)

    else:
       return render_template("index.html")


@app.route("/questions", methods=["GET", "POST"])
def questions():

    if request.method == "POST":
        # Handle POST request
        return render_template("questions.html")
    else:
        return render_template("questions.html")


@app.route("/submit1", methods=["POST"])
def submit1():
    score = 0
    score = int(request.form['q1']) + int(request.form['q2'])+ int(request.form['q3']) + int(request.form['q4']) + int(request.form['q5'])
    if score > 3:
        return render_template("questions2h.html")
    else:
        return render_template("questions2l.html")

@app.route("/submit2h", methods=["POST"])
def submit2h():
    score = 0
    score = int(request.form['q6']) + int(request.form['q7'])+ int(request.form['q8']) + int(request.form['q9']) + int(request.form['q10'])
    if score > 3:
        return render_template("questions3h.html")
    else:
        return render_template("questions3hl.html")
    
@app.route("/submit2l", methods=["POST"])
def submit2l():
    try:
        score = int(request.form['q6']) + int(request.form['q7'])+ int(request.form['q8']) + int(request.form['q9']) + int(request.form['q10'])
        if score > 3:
            return render_template("questions3hl.html")
        else:
            return render_template("questions3l.html")
    except:
        return "Error: Form data not properly formatted or received."

@app.route("/submit3h", methods=["POST"])
def submit3h():
    score = 0
    score = int(request.form['q11']) + int(request.form['q12'])+ int(request.form['q13']) + int(request.form['q14']) + int(request.form['q15'])
    iq = 150
    iq = iq + score * 10
    return render_template("results.html",iq=iq)

@app.route("/submit3hl", methods=["POST"])
def submit3hl():
    score = 0
    score = int(request.form['q11']) + int(request.form['q12'])+ int(request.form['q13']) + int(request.form['q14']) + int(request.form['q15'])
    iq = 100
    iq = iq + score * 10
    return render_template("results.html",iq=iq)

@app.route("/submit3l", methods=["POST"])
def submit3l():
    score = 0
    score = int(request.form['q11']) + int(request.form['q12'])+ int(request.form['q13']) + int(request.form['q14']) + int(request.form['q15'])
    iq = 50
    iq = iq + score * 10
    return render_template("results.html",iq=iq)