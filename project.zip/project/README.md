# IQ calculator
#### Video Demo:  <https://youtu.be/Ua36pVNVjx8>
#### Description:"Hi everyone, this is my CS50 project. I'm excited to present my IQ calculator app. One of the unique features of this app is that it only requires your name and age to get started. No lengthy sign-up process or personal information required.

Once you're in, the first page of the app will present you with 5 questions that will test your knowledge in different areas. The questions range in difficulty, and cover various topics such as math, logic, and language.

Once you complete the quiz, the app will allocate you a range of IQ based on how many questions you answered correctly. This range will determine the difficulty level of the next set of questions.

And at the end of the quiz, you'll receive your IQ score. Your IQ score will be within a range of 50 to 250.

So if you're ready to challenge yourself and test your intelligence, give this app a try. It's a great way to measure your cognitive abilities in a fun and engaging way."


index(): This function serves as the main entry point for the app, rendering the index page where the user inputs their name. When the user submits their name, the function checks that the name input is not empty, and then renders the "questions" page passing in the name as an argument.

questions(): This function renders the "questions" page, which displays a set of questions for the user to answer. If the user submits the form, the page reloads, displaying the same questions. If the user submits the form correctly, the app will redirect them to a page containing the next set of questions.

submit1(): This function handles the first set of questions. When the user submits the form, the function calculates the user's score based on the answers to the questions. If the score is greater than three, the app will redirect the user to the next set of harder questions. Otherwise, the app will redirect the user to the next set of easier questions.

submit2h(): This function handles the second set of harder questions. If the user's score is greater than three, the app will redirect the user to the next set of even harder questions. Otherwise, the app will redirect the user to the next set of easier questions.

submit2l(): This function handles the second set of easier questions. If the user's score is greater than three, the app will redirect the user to the next set of even harder questions. Otherwise, the app will redirect the user to the next set of even easier questions.

submit3h(): This function handles the third set of hardest questions. When the user submits the form, the function calculates the user's score based on the answers to the questions. It then calculates the user's IQ by adding the score to a base IQ of 150. The app will then render the "results" page, passing in the user's IQ as an argument.

submit3hl(): This function handles the third set of hard questions. When the user submits the form, the function calculates the user's score based on the answers to the questions. It then calculates the user's IQ by adding the score to a base IQ of 100. The app will then render the "results" page, passing in the user's IQ as an argument.

submit3l(): This function handles the third set of easiest questions. When the user submits the form, the function calculates the user's score based on the answers to the questions. It then calculates the user's IQ by adding the score to a base IQ of 50. The app will then render the "results" page, passing in the user's IQ as an argument.

I have chosen to write each function to serve a specific purpose within the app's logic flow. Each function handles a specific page or set of questions, and determines which page to redirect the user to based on their performance on the quiz. This creates a dynamic and engaging user experience, as the app adjusts the difficulty of the questions based on the user's performance.

The program assigns IQ scores based on the number of questions the user answered correctly in the quiz. The quiz consists of three sets of questions, with each set containing five questions. The difficulty of the questions in each set is determined by the user's performance in the previous set.

If the user scores high on the first set of questions, they will move on to the second set of questions, which are more difficult. If they score low, they will move on to the second set of easier questions. Similarly, the user's performance on the second set of questions will determine whether they move on to the third set of harder questions or the third set of easier questions.

Once the user completes the quiz, the program calculates their IQ score based on the number of questions they answered correctly. The score is within a range of 50 to 250, and is calculated by adding a base IQ score to the number of correct answers multiplied by 10. The base IQ score depends on which set of questions the user ended up answering, and ranges from 50 to 150.

I chose this approach for assigning IQ scores because it provides a simple and straightforward way to measure a user's intelligence based on their performance in a quiz. While IQ scores are a controversial topic in psychology, they are widely used as a measure of intelligence and can be useful in certain contexts. It's important to note that IQ scores are just one measure of intelligence, and that there are many different types of intelligence that can't be captured by a single test.