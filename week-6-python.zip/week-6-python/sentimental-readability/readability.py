from cs50 import get_string

s = get_string("Text: ")

# words
words = s.count(" ") + 1

# sentences
sentences = s.count(".") + s.count("!") + s.count("?")

# letter
letters = 0
for i in range(len(s)):
    if s[i].isalpha():
        letters += 1


# letters per 100 words & sentences per 100 words
l = letters * 100 / words
s = sentences * 100 / words

# grade index
grade = 0.0588 * l - 0.296 * s - 15.8

if grade < 1:
    print('Before Grade 1')
elif grade > 16:
    print('Grade 16+')
else:
    print(f'Grade {round(grade)}')