def get_height():
    while True:
        try:
            height = int(input('Height: '))
            if height > 0 and height < 9:
                return height
        except:
            ValueError
        print("Type an integer")


h = get_height()

for i in range(h):
    print(' ' * (h - 1 - i) + '#' * (i + 1))