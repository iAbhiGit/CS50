# Promting cashier for change owed
def get_change():
    while True:
        try:
            change = float(input('Change Owed: '))
            if change > 0:
                return change

        except:
            ValueError
        print('Invalid Input')


change = get_change()

# quarters
quarters = int(change / 0.25)
change = round(change % 0.25, 2)

# dimes
dimes = int(change / 0.10)
change = round(change % 0.10, 2)

# nickels
nickels = int(change / 0.05)
change = round(change % 0.05, 2)

# pennies
pennies = int(change / 0.01)
change = round(change % 0.01, 2)

# total coins
coins = quarters + dimes + nickels + pennies
print(coins)