name = input('What is your name?\n')
print(f'Hello, {name}')