// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cs50.h>
#include <strings.h>


#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 500;

// Hash table
node *table[N];
unsigned int wordcount = 0;

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    int hash_val = hash(word);

    for (node *cursor = table[hash_val]; cursor != NULL;)
    {
        if (strcasecmp(word, cursor->word) == 0)
        {
            return true;
        }
        cursor = cursor->next;

    }

    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO: Improve this hash function
    unsigned int sum = 0;
    unsigned int strlength = strlen(word);
    int i = 0;
    while (word[i] < strlength)
    {
        sum = sum + toupper(word[i]);
        i++;
    }
    return sum % N;
}


// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{

    //opening the dictionary file.
    FILE *filepointer = fopen(dictionary, "r");

    // if not opened return null
    if (filepointer == NULL)
    {
        printf("could't open the file");
        return false;
    }

    //Declare variable for word
    char word[LENGTH + 1];

    //Read each word using fscanf()

    while (fscanf(filepointer, "%s", word) != EOF)
    {
        unsigned int hash_val = 0;
        //allocate memory for the new node call *new
        node *new = malloc(sizeof(node));

        if (new == NULL)
        {
            return false;
        }

        //copy the scanned word into the new nodes word (changing *new.word, word syntax to new->word)
        strcpy(new->word, word);

        //Adding the copied word into the hash location
        hash_val = hash(word);

        //so that we dont lose the values at table hash val, we are pointing new next to table hash val.
        new->next = NULL;

        if (table[hash_val] == NULL)
        {
            table[hash_val] = new;
        }
        else
        {
            new->next = table[hash_val];
            table[hash_val] = new;
        }

        wordcount++;
    }
    fclose(filepointer);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO

    return wordcount;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO

    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];

        while (cursor != NULL)
        {
            node *tmp = cursor;
            cursor = cursor->next;
            free(tmp);
        }
        if (cursor == NULL)
        {
            return true;
        }
        // setting each tables head pointers to NULL
        free(table[i]);
    }


    return false;
}
